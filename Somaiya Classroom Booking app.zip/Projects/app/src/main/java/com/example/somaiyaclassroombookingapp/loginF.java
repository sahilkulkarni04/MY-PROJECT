package com.example.somaiyaclassroombookingapp;

//import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class loginF extends AppCompatActivity {

    EditText username;
    EditText password;
    Button loginButton;
    private FirebaseAuth mAuth;
//    private static final String TAG = "LoginF";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_f);

        mAuth = FirebaseAuth.getInstance();

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = username.getText().toString();
                String pwd = password.getText().toString();

                if (!email.isEmpty() && !pwd.isEmpty()) {
                    mAuth.signInWithEmailAndPassword(email, pwd)
                            .addOnCompleteListener(loginF.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
//                                        Log.d(TAG, "signInWithEmail:success");
                                        Toast.makeText(loginF.this, "Sign in successful.", Toast.LENGTH_SHORT).show();
                                        Intent i1 = new Intent(loginF.this, homePage.class);
//                                        i1.putExtra("EMAIL_EXTRA", email);
                                        startActivity(i1);
                                    } else {
//                                        Log.w(TAG, "signInWithEmail:failure", task.getException());
                                        Toast.makeText(loginF.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                } else {
                    // Handle the case where the email or password is empty
                    Toast.makeText(loginF.this, "Please enter both email and password.", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
