package com.example.somaiyaclassroombookingapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class from1 extends AppCompatActivity {

    private Spinner roleET;
    public String selectedRole;
    private Spinner eventET;
    public String selectedEvent;
    public String selectedTimeSlot;
    private EditText datePicker;
    private Spinner timeSlotET;
    private EditText nameEditText;
    private EditText otherEditText;
    private EditText idNoEditText;

    private DatabaseReference mDatabase;
    private Button submitButtton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_from1);

        // Initialize Firebase
        mDatabase = FirebaseDatabase.getInstance().getReference("bookings");

        // Initialize EditText fields
        roleET = findViewById(R.id.roleET);
        eventET = findViewById(R.id.eventET);
        datePicker = findViewById(R.id.datePicker);
        timeSlotET = findViewById(R.id.timeSlotET);
        submitButtton = findViewById(R.id.submitButton);
        nameEditText = findViewById(R.id.nameEditText);
        idNoEditText = findViewById(R.id.idNoEditText);
        otherEditText = findViewById(R.id.otherEditText);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.roles, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roleET.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.events, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        eventET.setAdapter(adapter2);

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,
                R.array.timeslot, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        timeSlotET.setAdapter(adapter3);

        roleET.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedRole = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        eventET.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedEvent = parent.getItemAtPosition(position).toString();

                String selectedItem = selectedEvent;

                if (selectedItem.equals("Others")) {
                    otherEditText.setVisibility(View.VISIBLE);
                }
                else {
                    otherEditText.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        timeSlotET.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedTimeSlot = parent.getItemAtPosition(position).toString();
//                String timeslot = selectedTimeslot;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        // Set click listener for the submit button
        submitButtton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString().trim();
                String id = idNoEditText.getText().toString().trim();
                String role = selectedRole;
                String event = selectedEvent;
                String date = datePicker.getText().toString().trim();
                String timeSlot = selectedTimeSlot;
                String otherEvent = otherEditText.getText().toString().trim();


                if (!role.isEmpty() && !event.isEmpty() && !date.isEmpty() && !timeSlot.isEmpty() && !name.isEmpty() && !id.isEmpty()) {
                    mDatabase.child("name").push().setValue(name);
                    mDatabase.child("id").push().setValue(id);
                    mDatabase.child("Roles").push().setValue(role);
                    mDatabase.child("Events").push().setValue(event);
                    mDatabase.child("others").push().setValue(otherEvent);
                    mDatabase.child("Date").push().setValue(date);
                    mDatabase.child("TimeSlot").push().setValue(timeSlot);

                    Toast.makeText(from1.this, "Details submitted successfully !", Toast.LENGTH_SHORT).show();

                    Intent i3 = new Intent(from1.this, roomMgmtFinal.class);
                    i3.putExtra("DATE",date);
                    i3.putExtra("TSLOT",timeSlot);
                    startActivity(i3);

                } else {
                    Toast.makeText(from1.this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
                    Intent i4 = new Intent(from1.this, homePage.class);
                    startActivity(i4);
                }
            }
        });
    }
}
