//package com.example.somaiyaclassroombookingapp;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.fragment.app.Fragment;
//
//import android.os.Bundle;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//
//public class BookingFragment extends Fragment {
//    private String status;
//
//    public BookingFragment(String status) {
//        this.status = status;
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        View view = inflater.inflate(R.layout.fragment_booking, container, false);
//        // Add code to display bookings based on the status (Pending, Approved, Edit)
//        return view;
//    }
//}