package com.example.somaiyaclassroombookingapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class roomMgmtFinal extends AppCompatActivity {
    public String selectedBuilding;
    public String selectedFloor;
    public static String selectedRoomNo;
    public String selectedCLab;
    private Spinner builSpinner;
    private Spinner floorSpinner;
    private Spinner roomNoSpinner1;
    private Spinner roomNoSpinner2;
    private Spinner roomNoSpinner3;
    private Spinner roomNoSpinner4;
    private EditText cLabET;
    private Button bookButton;
//    public String status;
    public static TextView msg;
    private DatabaseReference mDatabase;
//    private Button bookButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_mgmt_final);


        // Initialize Firebase
        mDatabase = FirebaseDatabase.getInstance().getReference("bookings");

//        Query query = ref.orderByChild("RoomNo").startAt(0);

        builSpinner = findViewById(R.id.builSpinner);
        floorSpinner = findViewById(R.id.floorSpinner);
        roomNoSpinner1 = findViewById(R.id.roomNoSpinner1);
        roomNoSpinner2 = findViewById(R.id.roomNoSpinner2);
        roomNoSpinner3 = findViewById(R.id.roomNoSpinner3);
        roomNoSpinner4 = findViewById(R.id.roomNoSpinner4);
        msg = findViewById(R.id.msg);
        cLabET = findViewById(R.id.cLabET);
        bookButton = findViewById(R.id.bookButton);

        Intent intent = getIntent();
        String date = intent.getStringExtra("DATE");
        String tslot = intent.getStringExtra("TSLOT");

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.buildings, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        builSpinner.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this,
                R.array.floor, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        floorSpinner.setAdapter(adapter2);

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this,
                R.array.roomNo1, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roomNoSpinner1.setAdapter(adapter3);

        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this,
                R.array.roomNo2, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roomNoSpinner2.setAdapter(adapter4);

        ArrayAdapter<CharSequence> adapter5 = ArrayAdapter.createFromResource(this,
                R.array.roomNo3, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roomNoSpinner3.setAdapter(adapter5);

        ArrayAdapter<CharSequence> adapter6 = ArrayAdapter.createFromResource(this,
                R.array.roomNo4, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roomNoSpinner4.setAdapter(adapter6);

        builSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedBuilding = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        floorSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedFloor = parent.getItemAtPosition(position).toString();

                String selectedItem = selectedFloor;



                if (selectedItem.equals("1")) {
                    roomNoSpinner1.setVisibility(View.VISIBLE);

                }
                else if(selectedItem.equals("2")){
                    roomNoSpinner2.setVisibility(View.VISIBLE);

                }
                else if(selectedItem.equals("3")){
                    roomNoSpinner3.setVisibility(View.VISIBLE);

                }
                else if(selectedItem.equals("4")){
                    roomNoSpinner4.setVisibility(View.VISIBLE);
                }
                else{
                    selectedFloor = "none";
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        roomNoSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedRoomNo = parent.getItemAtPosition(position).toString();
                checkValueWithFirebase(selectedRoomNo,date,tslot);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        roomNoSpinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedRoomNo = parent.getItemAtPosition(position).toString();
                checkValueWithFirebase(selectedRoomNo,date,tslot);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        roomNoSpinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedRoomNo = parent.getItemAtPosition(position).toString();
                checkValueWithFirebase(selectedRoomNo,date,tslot);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        roomNoSpinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, android.view.View view, int position, long id) {
                selectedRoomNo = parent.getItemAtPosition(position).toString();
                checkValueWithFirebase(selectedRoomNo,date,tslot);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        // Set click listener for the submit button
        bookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String buildingStr = selectedBuilding;
                String floorStr = selectedFloor;
                String roomNoStr = selectedRoomNo;
                String cLabStr = cLabET.getText().toString().trim();
                String statusStr = "booked";


                if (!buildingStr.isEmpty() && !floorStr.isEmpty() && !roomNoStr.isEmpty() && !cLabStr.isEmpty()) {
                    mDatabase.child("Building").push().setValue(buildingStr);
                    mDatabase.child("Floor").push().setValue(floorStr);
                    mDatabase.child("RoomNo").push().setValue(roomNoStr);
                    mDatabase.child("CLab").push().setValue(cLabStr);
                    mDatabase.child("status").push().setValue(statusStr);

                    Toast.makeText(roomMgmtFinal.this, "Booking Successful !", Toast.LENGTH_SHORT).show();

                    Intent i3 = new Intent(roomMgmtFinal.this, bookSuccess.class);
                    startActivity(i3);

                } else {
                    Toast.makeText(roomMgmtFinal.this, "Please fill all the fields", Toast.LENGTH_SHORT).show();
                }
            }
        });



    }

    private void checkValueWithFirebase(String selectedRoomNo,String selectedDate,String selectedTslot) {
        mDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // Assuming you have a node named "selectedValueNode" in your database
                String FetchedRoomNo = dataSnapshot.child("RoomNo").getValue(String.class);
                String FetchedDate = dataSnapshot.child("Date").getValue(String.class);
                String FetchedTimeSlot = dataSnapshot.child("TimeSlot").getValue(String.class);
                if (selectedRoomNo.equals(FetchedRoomNo) && selectedDate.equals(FetchedDate) && selectedTslot.equals(FetchedTimeSlot)) {
                    // Perform your desired action if the values match
                    // For example:
                    msg.setText("Room is already Booked !");
                    Toast.makeText(roomMgmtFinal.this, "Values Match!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                // Handle the error appropriately
            }
        });
    }
        private void checkValueWithFirebase2(String selectedValue2){
            mDatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    // Assuming you have a node named "selectedValueNode" in your database
                    String fetchedValue2 = dataSnapshot.child("Floor").getValue(String.class);
                    if (fetchedValue2 != null && selectedValue2.length() > 4) {
                        // Perform your desired action if the values match
                        // For example:
                        msg.setText("All rooms on floor are already Booked !");
                        Toast.makeText(roomMgmtFinal.this, "Booking full !", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    // Handle the error appropriately
                }
            });

        }

    }
