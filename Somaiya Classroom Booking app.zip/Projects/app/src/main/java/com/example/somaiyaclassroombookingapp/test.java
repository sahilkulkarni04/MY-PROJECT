package com.example.somaiyaclassroombookingapp;

public class test {
    private String name;

    public test(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
